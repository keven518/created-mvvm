// 创建一个TemplateCompiler模板编译工具
class TemplateCompiler {
  // 构造函数
  // 1、视图线索
  // 2、全局vm对象
  constructor(el, vm) {
    // 缓存重要的属性
    this.el = this.isElementNode(el)?el:document.querySelector(el);
    this.vm = vm;

    // 判断视图存在
    if(this.el) {
      // 1、把模板内容放入内存（片段）
      var fragment = this.node2fragment(this.el);
      // debugger;
      // 2、解析模板
      this.compile(fragment);
      // 3、把内存的结果，返回到页面
      this.el.appendChild(fragment);
    }
      
  }

  //***********工具方法*************/
  // 判断是否是元素节点
  isElementNode(node) {
    return node.nodeType === 1; // 1、元素节点， 2、属性节点， 3、文本节点
  }
  // 判断是否是文本节点
  isTextNode(node) {
    return node.nodeType === 3; //
  }
  toArray(fakeArr) {
    return [].slice.call(fakeArr);  // 假数组转成真数组
  }
  isDirective(attrName) { // v-text
    // debugger;
    return attrName.indexOf('v-') >= 0;
  }
  //*******************************/

  //***********核心方法*************/
  // 把模板放入内存，等待解析
  node2fragment(node) {
    // 1、创建内存片段
    var fragment = document.createDocumentFragment(),child;
    // debugger;
    // 2、把模板内容丢到内存
    while(child = node.firstChild) {
      fragment.appendChild(child);
    };
    // 3、返回
    return fragment;
  }
  // 解析模板
  compile(parent) {
    // 1、获取子节点
    var childNode = parent.childNodes,
        compiler = this;
    // 2、遍历每一个节点
    this.toArray(childNode).forEach((node) => {
      // 3、判断节点类型
        if(compiler.isElementNode(node)){
          // 1) 属性节点（解析指令）
          compiler.compileElement(node);
        }
        
        // 2) 文本节点（解析指令）
    });
  }

  // 解析元素节点的指令的
  compileElement(node) {
    // 1、获取当前元素节点的所有属性
    var arrs = node.attributes,
        compiler = this;
        // debugger;
    // 2、遍历当前元素的所有属性
    this.toArray(arrs).forEach(attr => {
      var attrName = attr.name;
      // 3、判断属性是否是指令
      if(compiler.isDirective(attrName)) {
        // 4、收集
          // 指令类型
          // var type = attrName.split('-')[1];
          var type = attrName.substr(2);
          // 指令的值就是表达式
          var expr = attr.value;
          // debugger;
        // 5、找帮手
        CompilerUtils.text(node, compiler.vm, expr)
      }

    })
    // debugger;
  }
  // 解析表达式的
  compileText() {

  }
}

// 帮手
CompilerUtils = {
  // 解析text指令
  text(node, vm, expr) {
    // 1. 找到更新规则对象的更新方法
    var updaterFn = this.updater['textUpdater'];
    // 2. 执行方法
    updaterFn && updaterFn(node, vm.$data[expr]);
  },

  // 更新规则对象
  updater: {
    // 文本更新方法
    textUpdater(node, value){
      node.textContent = value;
    }
  }

}